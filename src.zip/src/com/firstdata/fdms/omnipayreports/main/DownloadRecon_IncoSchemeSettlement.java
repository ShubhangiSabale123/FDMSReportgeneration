package com.firstdata.fdms.omnipayreports.main;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.supercsv.io.CsvBeanReader;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanReader;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import com.firstdata.fdms.omnipayreports.model.OutgoingInterchangeSummaryReportsReader;
import com.firstdata.fdms.omnipayreports.model.SubmissionsReportsAutomationReader;
import com.firstdata.fdms.omnipayreports.model.SubmissionsReportsAutomationWriter;
import com.firstdata.fdms.omnipayreports.utils.DownloadFDMSOmnipayReportsAutomationConstants;
import com.firstdata.fdms.omnipayreports.utils.DownloadFDMSOmnipayReportsAutomationMessages;
import com.firstdata.fdms.omnipayreports.utils.DownloadFDMSOmnipayReportsAutomationUtils;
import com.firstdata.fdms.omnipayreports.utils.DownloadFDMSOmnipayReportsAutomationWaitTool;
import com.firstdata.fdms.omnipayreports.utils.DownloadOutgoingInterchangeAutomationUtils;
import com.firstdata.fdms.omnipayreports.utils.DownloadRecon_IncoSchemeSettlementAutomationUtils;
import com.firstdata.fdms.omnipayreports.utils.ReadExcelUtility;
import com.firstdata.fdms.omnipayreports.utils.RenameCSVFileName;

public class DownloadRecon_IncoSchemeSettlement
{


	private Properties properties;
	private Properties objProperties=null;
	private WebDriver driver;
	private String baseUrl;
	private static int timeOut;
	private static String pageToLoad;
	private String currentdate = null;
	private String dataFailed = null;
	private String data;
	private String dataStatus ;
	private String errorDetails = null;
	private int errorCounter = 0;
	private int scrrenshotCounter=0;
	private String timeStamp="";
	private String ScreenShotFolder="";
	static FileWriter fileWriter = null;
	String DownlaodFilePath=null;
	String OutputFolderPath=null;
	String[] headerWriter = new String[] {"START_TIME", "END_TIME", "ROWNUM","INCOMING_INTERCHANGE","FROM_DATE","END_DATE","COMMENTS" };
	String header = Arrays.toString(headerWriter);


	//reader writer objects
	//SubmissionsReportsAutomationReader automationBeanReader=new SubmissionsReportsAutomationReader();
	//SubmissionsReportsAutomationWriter automationBeanWriter=new SubmissionsReportsAutomationWriter();

	private static Logger LOG = LoggerFactory.getLogger(DownloadSubmissionsReportsMain.class);

	//===============Setup Method=====================================

	public void setUp() throws Exception
	{
		try
		{
			LOG.info("----set up " + DownloadFDMSOmnipayReportsAutomationMessages.STARTED + "----");

			//Properties file name  
			String propertiesFileName ="properties/DownlaodFDMSOmnipayReports.properties";

			//Load properties file
			properties = DownloadFDMSOmnipayReportsAutomationUtils.loadProperties(properties, propertiesFileName);

			String objPropertiesFileName = "properties/DownlaodRecIncoSchemeSettlementObject.properties";
			//load object properties files
			objProperties = DownloadFDMSOmnipayReportsAutomationUtils.loadProperties(objProperties,objPropertiesFileName);

			//check for browser
			String  browser=properties.getProperty("browser");
			//gets browser
			driver=DownloadFDMSOmnipayReportsAutomationUtils.getBrowser(browser, driver, properties);

			if(properties.getProperty("url")!=null)
			{
				baseUrl = properties.getProperty("url").trim();
				driver.navigate().to(baseUrl);
			}
			else
			{
				LOG.info("Please check URL");
			}

			String timeOutStr = properties.getProperty("timeOut");
			timeOut = Integer.parseInt(timeOutStr);
			//maximize the window
			driver.manage().window().maximize();
			//implicitly wait
			driver.manage().timeouts().implicitlyWait(timeOut, TimeUnit.SECONDS);

			LOG.info("----set up " + DownloadFDMSOmnipayReportsAutomationMessages.FINISHED + "----");

		} catch (Exception e)
		{
			LOG.error(e.getMessage());
			//e.printStackTrace();
		}
	}

	public void Recon_IncoSchemeSettlement_Process() throws Exception
	{
		//driver.navigate().to(baseUrl);
		// render it on required url
		try
		{
			String username = properties.getProperty("username");
			String password = properties.getProperty("password");

			Calendar cal = Calendar.getInstance();
			SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy");
			currentdate = format.format(cal.getTime());


			pageToLoad = properties.getProperty("pageToLoadTimeOut");

			String InputFolder = properties.getProperty("InputFolder");
			String StatusFolder = properties.getProperty("StatusFolder");
			ScreenShotFolder = properties.getProperty("ScreenShotFolder");
			String ErrorFolder = properties.getProperty("ErrorFolder");
			DownlaodFilePath=properties.getProperty("DownlaodFilePath");
			OutputFolderPath=properties.getProperty("OutputFolder");

			SimpleDateFormat formatStatus = new SimpleDateFormat("dd-MM-yyyy HHmm");
			String currentdateStatus = formatStatus.format(cal.getTime());
			timeStamp = formatStatus.format(cal.getTime());

			// input file
			data = InputFolder + "\\" + "DownloadIntSchemesettlementReportsAutomation(" + currentdate + ").xlsx";
			// status file
			dataStatus = StatusFolder + "/" + "DownloadIntSchemesettlementReportsAutomation-Status(" + currentdateStatus + ").xlsx";
			// error file
			dataFailed = ErrorFolder + "/" + "DownloadIntSchemesettlementReportsAutomation-Error(" + currentdateStatus + ").xlsx";


			if (!(username.isEmpty()) && !(password.isEmpty()))
			{



				String[] files = new String[] {dataStatus,dataFailed };

				for (int i = 0; i < files.length; i++)
				{
					fileWriter = new FileWriter(files[i]);
					BufferedWriter writer = new BufferedWriter(fileWriter);
					writer.write(header);
					writer.append("\n");
					writer.flush();
					writer.close();
				}

				//call login method
				driver = DownloadFDMSOmnipayReportsAutomationUtils.login(objProperties, driver, username, password,properties);


				Thread.sleep(Integer.parseInt(properties.getProperty("timeoutAfterLogin")));


				try
				{
					//Thread.sleep(Integer.parseInt(properties.getProperty("timeoutbeforeClickedonMerchAdmin")));
					Actions actions = new Actions(driver);
					//move cursor on accounts
					//select merchantAdministration button
					WebElement clickedonReports=DownloadFDMSOmnipayReportsAutomationUtils.getLocator(objProperties, driver, "clickedonReports");
					DownloadFDMSOmnipayReportsAutomationWaitTool.waitForVisibilityOfElement(driver, clickedonReports, properties.getProperty("timeoutfor_element_tobevisible"));
					actions.moveToElement(clickedonReports).click().build().perform();
					LOG.info("Reports Button is clicked");
					Thread.sleep(Integer.parseInt(properties.getProperty("timeoutAfterEachElement")));

					//select Maintain Merchant Details
					WebElement clickedonReconciliation=DownloadFDMSOmnipayReportsAutomationUtils.getLocator(objProperties, driver, "clickedonReconciliation");
					DownloadFDMSOmnipayReportsAutomationWaitTool.waitForVisibilityOfElement(driver, clickedonReconciliation, properties.getProperty("timeoutfor_element_tobevisible"));
					actions.moveToElement(clickedonReconciliation).click().build().perform();
					Thread.sleep(Integer.parseInt(properties.getProperty("timeoutAfterEachElement")));

					WebElement clickedonIncSchSettlement=DownloadFDMSOmnipayReportsAutomationUtils.getLocator(objProperties, driver, "clickedonIncSchSettlement");
					DownloadFDMSOmnipayReportsAutomationWaitTool.waitForVisibilityOfElement(driver, clickedonIncSchSettlement, properties.getProperty("timeoutfor_element_tobevisible"));
					actions.moveToElement(clickedonIncSchSettlement).click().build().perform();
					Thread.sleep(Integer.parseInt(properties.getProperty("timeoutAfterEachElement")));


				}
				catch (Exception e1) 
				{
					 
					try
					{
						//Thread.sleep(Integer.parseInt(properties.getProperty("timeoutbeforeClickedonMerchAdmin")));
						Actions actions = new Actions(driver);
						//move cursor on accounts
						//select merchantAdministration button
						WebElement clickedonReports=DownloadFDMSOmnipayReportsAutomationUtils.getLocator(objProperties, driver, "clickedonReports");
						DownloadFDMSOmnipayReportsAutomationWaitTool.waitForVisibilityOfElement(driver, clickedonReports, properties.getProperty("timeoutfor_element_tobevisible"));
						actions.moveToElement(clickedonReports).click().build().perform();
						LOG.info("Reports Button is clicked");

						Thread.sleep(Integer.parseInt(properties.getProperty("timeoutAfterEachElement")));
						//select Maintain Merchant Details
						WebElement clickedonReconciliation=DownloadFDMSOmnipayReportsAutomationUtils.getLocator(objProperties, driver, "clickedonReconciliation");
						DownloadFDMSOmnipayReportsAutomationWaitTool.waitForVisibilityOfElement(driver, clickedonReconciliation, properties.getProperty("timeoutfor_element_tobevisible"));
						actions.moveToElement(clickedonReconciliation).click().build().perform();
						Thread.sleep(Integer.parseInt(properties.getProperty("timeoutAfterEachElement")));

						WebElement clickedonIncSchSettlement=DownloadFDMSOmnipayReportsAutomationUtils.getLocator(objProperties, driver, "clickedonIncSchSettlement");
						DownloadFDMSOmnipayReportsAutomationWaitTool.waitForVisibilityOfElement(driver, clickedonIncSchSettlement, properties.getProperty("timeoutfor_element_tobevisible"));
						actions.moveToElement(clickedonIncSchSettlement).click().build().perform();
						Thread.sleep(Integer.parseInt(properties.getProperty("timeoutAfterEachElement")));
					}
					catch (Exception e) 
					{
						e.printStackTrace();
						File scrShotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
						String fileName = "Screenshot_selectingSubmenu_"+scrrenshotCounter + timeStamp + ".png";
						FileUtils.copyFile(scrShotFile, new File(ScreenShotFolder + "//" + currentdate + "//" + fileName));
						scrrenshotCounter++;
						errorDetails = "Error while selecting submenu options ="+  e.getMessage() + "";

						errorCounter++;
						LOG.error(errorDetails);
						//int sheetNo,String Value,int row,int col
					//	DownloadRecon_IncoSchemeSettlementAutomationUtils.writeErrorLogs(dataFailed, errorDetails, errorCounter, headerWriter,int row,int col);


					}



				}
				//=============================================================================
				ReadExcelUtility readExcel=new ReadExcelUtility(data);
				int RowCount= readExcel.getRowCount(0);
				System.out.println("RowCount= "+RowCount);
				
				for(int row=1;row<=RowCount;row++)
				{
					
					
					//Delete existing downloaded file if present

					try
					{
						//delete files
						File[] Fetchfile = new File(DownlaodFilePath).listFiles();
						for (File file : Fetchfile)
						{
							//System.out.println("filename= "+file.getName().endsWith(".pdf"));
							if(file.isFile()&& (file.getName().toUpperCase().contains(properties.getProperty("username"))&& file.getName().endsWith(".csv")))
							{
								file.delete();
								LOG.info(file.getName()+ "file is deleted  ");
							}
						}
					}
					catch(Exception e)
					{
						e.printStackTrace();
					}
					
					int ColumnCount=readExcel.getColCount(0);
					System.out.println("ColumnCount= "+ColumnCount);
					
					for(int col=0;col<ColumnCount;col++)
					{


						//System.out.println(readExcel.getData(0, row, col));
						if(col==0)
						{
							String IncommingInterchange =readExcel.getData(0, row, col);
							System.out.println("IncommingInterchange="+IncommingInterchange);
							WebElement selectIncommingInterchange=DownloadFDMSOmnipayReportsAutomationUtils.getLocator(objProperties, driver, "selectIncommingInterchange");
							DownloadFDMSOmnipayReportsAutomationWaitTool.waitForVisibilityOfElement(driver, selectIncommingInterchange, properties.getProperty("timeoutfor_element_tobevisible"));
							//selectIncommingInterchange.clear();
							selectIncommingInterchange.sendKeys(IncommingInterchange );
						}
						if(col==1)
						{
							String getPostingStartDate =readExcel.getData(0, row, col);
							System.out.println("getPostingStartDate="+getPostingStartDate);
							WebElement PostingStartDate=DownloadFDMSOmnipayReportsAutomationUtils.getLocator(objProperties, driver, "PostingStartDate");
							DownloadFDMSOmnipayReportsAutomationWaitTool.waitForVisibilityOfElement(driver, PostingStartDate, properties.getProperty("timeoutfor_element_tobevisible"));
							PostingStartDate.click();
							PostingStartDate.sendKeys(Keys.chord(Keys.CONTROL, "a"), getPostingStartDate);
							//PostingStartDate.clear();
							//PostingStartDate.sendKeys(getPostingStartDate );
						}
					
						else if(col==2)
						{
							Thread.sleep(100);
							String getPostingEndDate =readExcel.getData(0, row, col);
							System.out.println("getPostingEndDate="+getPostingEndDate);
							WebElement PostingEndDate=DownloadFDMSOmnipayReportsAutomationUtils.getLocator(objProperties, driver, "PostingEndDate");
							DownloadFDMSOmnipayReportsAutomationWaitTool.waitForVisibilityOfElement(driver, PostingEndDate, properties.getProperty("timeoutfor_element_tobevisible"));
							PostingEndDate.sendKeys(Keys.chord(Keys.CONTROL, "a"), getPostingEndDate);
							//	PostingEndDate.clear();
							//PostingEndDate.sendKeys(getPostingEndDate );
						}
						else
						{
							//break;
						}

					}
				
					WebElement clickedonSearchButton=DownloadFDMSOmnipayReportsAutomationUtils.getLocator(objProperties, driver, "clickedonSearchButton");
					DownloadFDMSOmnipayReportsAutomationWaitTool.waitForVisibilityOfElement(driver, clickedonSearchButton, properties.getProperty("timeoutfor_element_tobevisible"));
					clickedonSearchButton.click();
					LOG.info("Clicked on search button");
					Thread.sleep(Integer.parseInt(properties.getProperty("timeoutAfterclickedonSearchButton")));

				}//End for loop

			}//If loop
			else
			{
				errorDetails = "Please check username and password is correct or not";
				LOG.error(errorDetails);
				errorCounter++;
				/*DownloadOutgoingInterchangeAutomationUtils.writeErrorLogs(beanReader, beanWriter, beanErrorWriter, errorDetails, automationBeanWriter, automationBeanReader, 
						errorCounter, dataFailed, headerWriter);*/
			}
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			errorDetails="Please check input file,should be in correct format.."+e.getMessage();
			LOG.error(errorDetails+" "+e.getMessage());
			/*DownloadOutgoingInterchangeAutomationUtils.writeErrorLogs(beanReader,beanWriter, beanErrorWriter, errorDetails,automationBeanWriter, automationBeanReader,
					errorCounter, dataFailed, headerWriter);*/
		}
	}


	// close driver
	public void tearDown() throws Exception
	{
		try
		{
			driver.quit();

			LOG.info("driver " + DownloadFDMSOmnipayReportsAutomationMessages.CLOSED + "");
		} catch (Exception e)
		{
			e.printStackTrace();
			LOG.error("Error while quiting the driver " + e.getMessage());
		}
	}

	//Main function
	public static void main(String[] args) throws Exception
	{
		DownloadRecon_IncoSchemeSettlement automation=new DownloadRecon_IncoSchemeSettlement();
		automation.setUp();
		automation.Recon_IncoSchemeSettlement_Process();
		automation.tearDown();
	}

}





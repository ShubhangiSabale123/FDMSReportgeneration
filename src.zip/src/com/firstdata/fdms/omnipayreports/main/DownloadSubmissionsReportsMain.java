package com.firstdata.fdms.omnipayreports.main;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.eclipse.jetty.util.log.Log;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.supercsv.io.CsvBeanReader;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanReader;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import com.firstdata.fdms.omnipayreports.model.SubmissionsReportsAutomationReader;
import com.firstdata.fdms.omnipayreports.model.SubmissionsReportsAutomationWriter;
import com.firstdata.fdms.omnipayreports.utils.DownloadFDMSOmnipayReportsAutomationMessages;
import com.firstdata.fdms.omnipayreports.utils.DownloadFDMSOmnipayReportsAutomationUtils;
import com.firstdata.fdms.omnipayreports.utils.DownloadFDMSOmnipayReportsAutomationConstants;
import com.firstdata.fdms.omnipayreports.utils.DownloadFDMSOmnipayReportsAutomationWaitTool;
import com.firstdata.fdms.omnipayreports.utils.RenameExcelFileName;

public class DownloadSubmissionsReportsMain 
{

	private Properties properties;
	private Properties objProperties=null;
	private WebDriver driver;
	private String baseUrl;
	private static int timeOut;
	private static String pageToLoad;
	private String currentdate = null;
	private String dataFailed = null;
	private String data;
	private String dataStatus ;
	private String errorDetails = null;
	private int errorCounter = 0;
	private int scrrenshotCounter=0;
	private String timeStamp="";
	private String ScreenShotFolder="";
	static ICsvBeanReader beanReader = null;  //FOR READING THE FILE
	static ICsvBeanWriter beanWriter = null;  //for wring in the file
	static ICsvBeanWriter beanErrorWriter = null;  //for wring error
	static FileWriter fileWriter = null;
	static ICsvBeanReader chargesBeanReader = null;
	String DownlaodFilePath=null;
	String OutputFolderPath=null;
	String[] headerWriter = new String[] {"START_TIME", "END_TIME", "ROWNUM","FROM_DATE","TO_DATE","CURRENCY","COMMENTS" };
	String header = Arrays.toString(headerWriter);


	//reader writer objects
	SubmissionsReportsAutomationReader automationBeanReader=new SubmissionsReportsAutomationReader();
	SubmissionsReportsAutomationWriter automationBeanWriter=new SubmissionsReportsAutomationWriter();

	private static Logger LOG = LoggerFactory.getLogger(DownloadSubmissionsReportsMain.class);

	//===============Setup Method=====================================

	public void setUp() throws Exception
	{
		try
		{
			LOG.info("----set up " + DownloadFDMSOmnipayReportsAutomationMessages.STARTED + "----");

			//Properties file name  
			String propertiesFileName ="properties/DownlaodFDMSOmnipayReports.properties";

			//Load properties file
			properties = DownloadFDMSOmnipayReportsAutomationUtils.loadProperties(properties, propertiesFileName);

			String objPropertiesFileName = "properties/DownlaodFDMSOmnipayReportsObject.properties";
			//load object properties files
			objProperties = DownloadFDMSOmnipayReportsAutomationUtils.loadProperties(objProperties,objPropertiesFileName);

			//check for browser
			String  browser=properties.getProperty("browser");
			//gets browser
			driver=DownloadFDMSOmnipayReportsAutomationUtils.getBrowser(browser, driver, properties);

			if(properties.getProperty("url")!=null)
			{
				baseUrl = properties.getProperty("url").trim();
				driver.navigate().to(baseUrl);
			}
			else
			{
				LOG.info("Please check URL");
			}

			String timeOutStr = properties.getProperty("timeOut");
			timeOut = Integer.parseInt(timeOutStr);
			//maximize the window
			driver.manage().window().maximize();
			//implicitly wait
			driver.manage().timeouts().implicitlyWait(timeOut, TimeUnit.SECONDS);

			LOG.info("----set up " + DownloadFDMSOmnipayReportsAutomationMessages.FINISHED + "----");

		} catch (Exception e)
		{
			LOG.error(e.getMessage());
			//e.printStackTrace();
		}
	}


	public void TIDDeactivation_Process() throws Exception
	{
		//driver.navigate().to(baseUrl);
		// render it on required url
		try
		{
			String username = properties.getProperty("username");
			String password = properties.getProperty("password");

			Calendar cal = Calendar.getInstance();
			SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy");
			currentdate = format.format(cal.getTime());


			pageToLoad = properties.getProperty("pageToLoadTimeOut");

			String InputFolder = properties.getProperty("InputFolder");
			String StatusFolder = properties.getProperty("StatusFolder");
			ScreenShotFolder = properties.getProperty("ScreenShotFolder");
			String ErrorFolder = properties.getProperty("ErrorFolder");
			DownlaodFilePath=properties.getProperty("DownlaodFilePath");
			OutputFolderPath=properties.getProperty("OutputFolder");

			SimpleDateFormat formatStatus = new SimpleDateFormat("dd-MM-yyyy HHmm");
			String currentdateStatus = formatStatus.format(cal.getTime());
			timeStamp = formatStatus.format(cal.getTime());

			// input file
			data = InputFolder + "/" + "DownloadSubmissionsReportsAutomation(" + currentdate + ").csv";
			// status file
			dataStatus = StatusFolder + "/" + "DownloadSubmissionsReportsAutomation-Status(" + currentdateStatus + ").csv";
			// error file
			dataFailed = ErrorFolder + "/" + "DownloadSubmissionsReportsAutomation-Error(" + currentdateStatus + ").csv";


			if (!(username.isEmpty()) && !(password.isEmpty()))
			{

				beanReader = new CsvBeanReader(new FileReader(data), CsvPreference.STANDARD_PREFERENCE);
				//create and write header in the file
				String[] headerReader = beanReader.getHeader(true);
				header = header.substring(1, header.length() - 1).replaceAll(", ", ",");
				String[] files = new String[] {dataStatus,dataFailed };

				for (int i = 0; i < files.length; i++)
				{
					fileWriter = new FileWriter(files[i]);
					BufferedWriter writer = new BufferedWriter(fileWriter);
					writer.write(header);
					writer.append("\n");
					writer.flush();
					writer.close();
				}

				//call login method
				driver = DownloadFDMSOmnipayReportsAutomationUtils.login(objProperties, driver, username, password,properties);

				/*try
				{
					Alert promptAlert = driver.switchTo().alert();
					promptAlert.accept();
				} catch (Exception e)
				{
					//e.printStackTrace();
				}*/

				//create folder for keeping sceenshot of a deteleted tid

				Thread.sleep(Integer.parseInt(properties.getProperty("timeoutAfterLogin")));

				try
				{
					Actions actions = new Actions(driver);
					//move cursor on accounts
					//select merchantAdministration button
					WebElement clickedonReports=DownloadFDMSOmnipayReportsAutomationUtils.getLocator(objProperties, driver, "clickedonReports");
					DownloadFDMSOmnipayReportsAutomationWaitTool.waitForVisibilityOfElement(driver, clickedonReports, properties.getProperty("timeoutfor_element_tobevisible"));
					actions.moveToElement(clickedonReports).click().build().perform();
					LOG.info("Reports Button is clicked");


					//select Maintain Merchant Details
					WebElement clickedonDataCapture=DownloadFDMSOmnipayReportsAutomationUtils.getLocator(objProperties, driver, "clickedonDataCapture");
					DownloadFDMSOmnipayReportsAutomationWaitTool.waitForVisibilityOfElement(driver, clickedonDataCapture, properties.getProperty("timeoutfor_element_tobevisible"));
					actions.moveToElement(clickedonDataCapture).click().build().perform();

					LOG.info("clicked on DataCapture");
					WebElement clickedonSubmissions=DownloadFDMSOmnipayReportsAutomationUtils.getLocator(objProperties, driver, "clickedonSubmissions");
					DownloadFDMSOmnipayReportsAutomationWaitTool.waitForVisibilityOfElement(driver, clickedonSubmissions, properties.getProperty("timeoutfor_element_tobevisible"));
					actions.moveToElement(clickedonSubmissions).click().build().perform();
					Thread.sleep(Integer.parseInt(properties.getProperty("timeoutAfterEachElement")));
				}
				catch (Exception e1) 
				{
					try
					{
						Actions actions = new Actions(driver);
						//move cursor on accounts
						WebElement clickedonReports=DownloadFDMSOmnipayReportsAutomationUtils.getLocator(objProperties, driver, "clickedonReports");
						DownloadFDMSOmnipayReportsAutomationWaitTool.waitForVisibilityOfElement(driver, clickedonReports, properties.getProperty("timeoutfor_element_tobevisible"));
						actions.moveToElement(clickedonReports).click().build().perform();
						LOG.info("Reports Button is clicked");


						//select Maintain Merchant Details
						WebElement clickedonDataCapture=DownloadFDMSOmnipayReportsAutomationUtils.getLocator(objProperties, driver, "clickedonDataCapture");
						DownloadFDMSOmnipayReportsAutomationWaitTool.waitForVisibilityOfElement(driver, clickedonDataCapture, properties.getProperty("timeoutfor_element_tobevisible"));
						actions.moveToElement(clickedonDataCapture).click().build().perform();

						LOG.info("clicked on DataCapture");

						WebElement clickedonSubmissions=DownloadFDMSOmnipayReportsAutomationUtils.getLocator(objProperties, driver, "clickedonSubmissions");
						DownloadFDMSOmnipayReportsAutomationWaitTool.waitForVisibilityOfElement(driver, clickedonSubmissions, properties.getProperty("timeoutfor_element_tobevisible"));
						actions.moveToElement(clickedonSubmissions).click().build().perform();
						Thread.sleep(Integer.parseInt(properties.getProperty("timeoutAfterEachElement")));
						Thread.sleep(Integer.parseInt(properties.getProperty("timeoutAfterEachElement")));
					}
					catch (Exception e) 
					{
						e.printStackTrace();
						File scrShotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
						String fileName = "Screenshot_selectingSubmenu_"+scrrenshotCounter + timeStamp + ".png";
						FileUtils.copyFile(scrShotFile, new File(ScreenShotFolder + "//" + currentdate + "//" + fileName));
						scrrenshotCounter++;
						errorDetails = "Error while selecting submenu options ="+  e.getMessage() + "";

						errorCounter++;
						LOG.error(errorDetails);
						DownloadFDMSOmnipayReportsAutomationUtils.writeErrorLogs(beanReader,beanWriter, beanErrorWriter, errorDetails,automationBeanWriter, automationBeanReader,
								errorCounter, dataFailed, headerWriter);
					}

				}
				try
				{
				while ((automationBeanReader = beanReader.read(SubmissionsReportsAutomationReader.class, headerReader, SubmissionsReportsAutomationReader.getProcessors())) != null)
				{
					long startTime = System.currentTimeMillis();
					DateFormat dateFormat1 = new SimpleDateFormat("dd/MM/yyyy");
					boolean isFileRenamed = false;
					try
					{
						beanWriter = new CsvBeanWriter(new FileWriter(dataStatus, true), CsvPreference.STANDARD_PREFERENCE);

						automationBeanWriter.setSTART_TIME(String.valueOf(new SimpleDateFormat(DownloadFDMSOmnipayReportsAutomationConstants.TIMESTAMP).format(new Date())));
						automationBeanWriter.setROWNUM(String.valueOf(beanReader.getLineNumber()));
						String strDate = dateFormat1.format(automationBeanReader.getFROM_DATE());
						automationBeanWriter.setFROM_DATE(strDate);
						String toDate = dateFormat1.format(automationBeanReader.getTO_DATE());
						automationBeanWriter.setTO_DATE(toDate);
						automationBeanWriter.setCURRENCY(automationBeanReader.getCURRENCY());

						LOG.info("Case Id " + DownloadFDMSOmnipayReportsAutomationMessages.STARTED +" For Row (" + beanReader.getRowNumber() + ") on : "
								+ new SimpleDateFormat(DownloadFDMSOmnipayReportsAutomationConstants.TIMESTAMP).format(new Date()));

						boolean isMandatory = DownloadFDMSOmnipayReportsAutomationUtils.isMandatory(beanReader, beanWriter, beanErrorWriter, errorDetails, automationBeanWriter, automationBeanReader, errorCounter,
								dataFailed, headerWriter);

						try
						{
							//delete files
							File[] Fetchfile = new File(DownlaodFilePath).listFiles();
							for (File file : Fetchfile)
							{
								//System.out.println("filename= "+file.getName().endsWith(".pdf"));
								//	if(file.isFile()&& (file.getName().toUpperCase().contains(properties.getProperty("username").toUpperCase())&& file.getName().endsWith(".xls")) )

								if(file.isFile()&& (file.getName().toUpperCase().contains("SUBMISSION_SEARCH")&& file.getName().endsWith(".xls")) )
								{
									file.delete();
									LOG.info(file.getName()+ "file is deleted  ");
								}


							}
						}
						catch(Exception e)
						{
							//e.printStackTrace();
							errorCounter++;
							errorDetails = "Please check DownlaodFilePath ";

							LOG.error(errorDetails);
							DownloadFDMSOmnipayReportsAutomationUtils.writeErrorLogs(beanReader, beanWriter, beanErrorWriter, errorDetails, automationBeanWriter, automationBeanReader,
									errorCounter, dataFailed, headerWriter);
						}
						boolean isMIDEntered=false;
						if(isMandatory)
						{


							try
							{
								//Date date1 = Calendar.getInstance().getTime();
							
								
								
								WebElement enterFromDate=DownloadFDMSOmnipayReportsAutomationUtils.getLocator(objProperties, driver, "enterFromDate");
								DownloadFDMSOmnipayReportsAutomationWaitTool.fluentWait(driver, enterFromDate, properties.getProperty("maxtimeout"), properties.getProperty("pollingtimeout"));
								//DownloadFDMSOmnipayReportsAutomationWaitTool.waitForVisibilityOfElement(driver, enterFromDate, properties.getProperty("timeoutfor_element_tobevisible"));
								enterFromDate.clear();
								//String strDate = dateFormat1.format(automationBeanReader.getFROM_DATE());
								Date date = Calendar.getInstance().getTime();
								 strDate = dateFormat1.format(automationBeanReader.getFROM_DATE());
								enterFromDate.sendKeys(strDate);
								LOG.info("From date is entered");
								Thread.sleep(100);

								WebElement enterToDate=DownloadFDMSOmnipayReportsAutomationUtils.getLocator(objProperties, driver, "enterToDate");
								DownloadFDMSOmnipayReportsAutomationWaitTool.waitForVisibilityOfElement(driver, enterToDate, properties.getProperty("timeoutfor_element_tobevisible"));
								enterToDate.clear();
								 toDate = dateFormat1.format(automationBeanReader.getTO_DATE());
								enterToDate.sendKeys(toDate);
								LOG.info("To date is entered");
								Thread.sleep(1000);

								try
								{
									WebElement selectCurrency=DownloadFDMSOmnipayReportsAutomationUtils.getLocator(objProperties, driver, "selectCurrency");
									DownloadFDMSOmnipayReportsAutomationWaitTool.waitForVisibilityOfElement(driver, selectCurrency, properties.getProperty("timeoutfor_element_tobevisible"));
									Select getcurrency=new Select(selectCurrency);
									String[] getCurrencyfrmProp=objProperties.getProperty("getCurrencyData").split("##");

									for(int i=0;i<getCurrencyfrmProp.length;i++)
									{
										if(getCurrencyfrmProp[i].contains(automationBeanReader.getCURRENCY()))
										{
											getcurrency.selectByVisibleText(getCurrencyfrmProp[i]);
											LOG.info("Currency is selected");
											break;
										}

									}
								}
								catch(Exception e)
								{
									e.printStackTrace();
									errorDetails = "Failed to select Currency  ="+  e.getMessage() + "";

									errorCounter++;
									LOG.error(errorDetails);
									DownloadFDMSOmnipayReportsAutomationUtils.writeErrorLogs(beanReader,beanWriter, beanErrorWriter, errorDetails,automationBeanWriter, automationBeanReader,
											errorCounter, dataFailed, headerWriter);
								}
								//selct bin
								try
								{
									WebElement selectBin=DownloadFDMSOmnipayReportsAutomationUtils.getLocator(objProperties, driver, "selectBin");
									DownloadFDMSOmnipayReportsAutomationWaitTool.waitForVisibilityOfElement(driver, selectBin, properties.getProperty("timeoutfor_element_tobevisible"));
									Select getbin=new Select(selectBin);
									getbin.selectByVisibleText("All BINs/ICAs");
									LOG.info("Bin is selected");
								}
								catch(Exception e)
								{
									e.printStackTrace();
									File scrShotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
									String fileName = "Screenshot_failedtoenterDate_"+scrrenshotCounter + timeStamp + ".png";
									FileUtils.copyFile(scrShotFile, new File(ScreenShotFolder + "//" + currentdate + "//" + fileName));
									scrrenshotCounter++;
									errorDetails = "Failed to select bin  ="+  e.getMessage() + "";

									errorCounter++;
									LOG.error(errorDetails);
									DownloadFDMSOmnipayReportsAutomationUtils.writeErrorLogs(beanReader,beanWriter, beanErrorWriter, errorDetails,automationBeanWriter, automationBeanReader,
											errorCounter, dataFailed, headerWriter);
								}

								//Clicked on show country
								WebElement clickedonShowCountry=DownloadFDMSOmnipayReportsAutomationUtils.getLocator(objProperties, driver, "clickedonShowCountry");
								DownloadFDMSOmnipayReportsAutomationWaitTool.waitForVisibilityOfElement(driver, clickedonShowCountry, properties.getProperty("timeoutfor_element_tobevisible"));
								if(!clickedonShowCountry.isSelected())
								{
									clickedonShowCountry.click();
									LOG.info("Show country is selected");
								}

								//select reporttype
								WebElement reportType=DownloadFDMSOmnipayReportsAutomationUtils.getLocator(objProperties, driver, "reportType");
								DownloadFDMSOmnipayReportsAutomationWaitTool.waitForVisibilityOfElement(driver, reportType, properties.getProperty("timeoutfor_element_tobevisible"));
								reportType.click();
								Select selectreport=new Select(reportType);
								selectreport.selectByVisibleText("All Submissions");

								WebElement clickedonSearchButton=DownloadFDMSOmnipayReportsAutomationUtils.getLocator(objProperties, driver, "clickedonSearchButton");
								DownloadFDMSOmnipayReportsAutomationWaitTool.waitForVisibilityOfElement(driver, clickedonSearchButton, properties.getProperty("timeoutfor_element_tobevisible"));
								if(clickedonSearchButton.isDisplayed())
								{
									clickedonSearchButton.click();
									LOG.info("Clicked on search button");
									Thread.sleep(Integer.parseInt(properties.getProperty("timeoutAfterclickedonSearchButton")));
								}


							}
							catch(Exception e)
							{
								e.printStackTrace();
								File scrShotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
								String fileName = "Screenshot_failedtoenterDate_"+scrrenshotCounter + timeStamp + ".png";
								FileUtils.copyFile(scrShotFile, new File(ScreenShotFolder + "//" + currentdate + "//" + fileName));
								scrrenshotCounter++;
								errorDetails = "Error while enetring the Date  ="+  e.getMessage() + "";

								errorCounter++;
								LOG.error(errorDetails);
								DownloadFDMSOmnipayReportsAutomationUtils.writeErrorLogs(beanReader,beanWriter, beanErrorWriter, errorDetails,automationBeanWriter, automationBeanReader,
										errorCounter, dataFailed, headerWriter);
							}
							String parentwindow=driver.getWindowHandle();
							boolean isRecordFound=false;

							try
							{

								WebElement clickedondownloadBtn=DownloadFDMSOmnipayReportsAutomationUtils.getLocator(objProperties, driver, "clickedondownloadBtn");
								DownloadFDMSOmnipayReportsAutomationWaitTool.fluentWait(driver, clickedondownloadBtn, properties.getProperty("maxtimeout"), properties.getProperty("pollingtimeout"));
								//waitForVisibilityOfElement(driver, clickedondownloadBtn, properties.getProperty("timeoutfor_element_tobevisible"));

								if(clickedondownloadBtn.isDisplayed() && clickedondownloadBtn.isEnabled())
								{
									clickedondownloadBtn.click();
									LOG.info("Clicked on Download button");
									isRecordFound=true;
								}
								else
								{
									LOG.info("No Results Found");
									isRecordFound=false;
									File scrShotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
									String fileName = "Screenshot_Norecord_"+scrrenshotCounter + timeStamp + ".png";
									FileUtils.copyFile(scrShotFile, new File(ScreenShotFolder + "//" + currentdate + "//" + fileName));
									scrrenshotCounter++;
									errorDetails = "No record";

									errorCounter++;
									LOG.error(errorDetails);
									DownloadFDMSOmnipayReportsAutomationUtils.writeErrorLogs(beanReader,beanWriter, beanErrorWriter, errorDetails,automationBeanWriter, automationBeanReader,
											errorCounter, dataFailed, headerWriter);
								}
							}
							catch(Exception e)
							{
								//e.printStackTrace();
								isRecordFound=false;
								errorDetails = "No record found "+e.getMessage();

								errorCounter++;
								LOG.error(errorDetails);
								DownloadFDMSOmnipayReportsAutomationUtils.writeErrorLogs(beanReader,beanWriter, beanErrorWriter, errorDetails,automationBeanWriter, automationBeanReader,
										errorCounter, dataFailed, headerWriter);
							}
							if(isRecordFound)
							{
								try
								{


									WebElement selectExcelDownload=DownloadFDMSOmnipayReportsAutomationUtils.getLocator(objProperties, driver, "selectExcelDownload");
									DownloadFDMSOmnipayReportsAutomationWaitTool.waitForVisibilityOfElement(driver, selectExcelDownload, properties.getProperty("timeoutfor_element_tobevisible"));
									//downloadAct.moveToElement(selectCSVDownload).click().build().perform();
									selectExcelDownload.click();
									LOG.info("clicked on excel download button");

									Thread.sleep(Integer.parseInt(properties.getProperty("timeoutAfterclickedonExcelDownload")));
									/*driver.switchTo().window("ShowPageWindow");
									driver.manage().window().maximize();

									Thread.sleep(200);

									WebElement clickedonDownloadAsCSV=DownloadFDMSOmnipayReportsAutomationUtils.getLocator(objProperties, driver, "clickedonDownloadAsCSV");
									DownloadFDMSOmnipayReportsAutomationWaitTool.waitForVisibilityOfElement(driver, clickedonDownloadAsCSV, properties.getProperty("timeoutfor_element_tobevisible"));
									clickedonDownloadAsCSV.click();
									LOG.info("Download as csv file");
									Thread.sleep(Integer.parseInt(properties.getProperty("timeoutAfterclickedonDownloadAsCSV")));
									driver.close();

									driver.switchTo().window(parentwindow);*/

								}catch(Exception e)
								{
									e.printStackTrace();
									File scrShotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
									String fileName = "Screenshot_failedtoDownloadReport_"+scrrenshotCounter + timeStamp + ".png";
									FileUtils.copyFile(scrShotFile, new File(ScreenShotFolder + "//" + currentdate + "//" + fileName));
									scrrenshotCounter++;
									errorDetails = "Failed to Download Reports for the  MID ="+  e.getMessage() + "";

									errorCounter++;
									LOG.error(errorDetails);
									DownloadFDMSOmnipayReportsAutomationUtils.writeErrorLogs(beanReader,beanWriter, beanErrorWriter, errorDetails,automationBeanWriter, automationBeanReader,
											errorCounter, dataFailed, headerWriter);
								}
								



								isFileRenamed=RenameExcelFileName.renameAndMoveFile(driver,DownlaodFilePath, OutputFolderPath, properties, beanReader, beanWriter, beanErrorWriter, errorDetails, automationBeanWriter, 
										automationBeanReader, errorCounter, dataFailed, headerWriter);
								Thread.sleep(1000);

								try
								{
									if(!isFileRenamed)
									{
										File[] Fetchfile = new File(DownlaodFilePath).listFiles();
										for (File file : Fetchfile)
										{
											//System.out.println("filename= "+file.getName().endsWith(".pdf"));
											//if(file.isFile()&& (file.getName().contains(properties.getProperty("username").toUpperCase())&& file.getName().endsWith(".xls")) )
											if(file.isFile()&& (file.getName().toUpperCase().contains("SUBMISSION_SEARCH")&& file.getName().endsWith(".xls")) )
											{
												file.delete();

											}
										}

									}
								}
								catch(Exception e)
								{
									e.printStackTrace();
									errorCounter++;
									errorDetails = "Please check DownlaodFilePath ";

									LOG.error(errorDetails);
									DownloadFDMSOmnipayReportsAutomationUtils.writeErrorLogs(beanReader, beanWriter, beanErrorWriter, errorDetails, automationBeanWriter, automationBeanReader,
											errorCounter, dataFailed, headerWriter);
								}

							}//if


							if (errorCounter==0 && isFileRenamed)
							{
								DownloadFDMSOmnipayReportsAutomationUtils.writeRecordStatus(driver, automationBeanWriter, beanWriter, beanReader, headerWriter);
							}

							//}


						}//mandatory
						LOG.info("Case Id " + DownloadFDMSOmnipayReportsAutomationMessages.FINISHED + " For Row (" + beanReader.getRowNumber() + ") on : "
								+ new SimpleDateFormat(DownloadFDMSOmnipayReportsAutomationConstants.TIMESTAMP).format(new Date()));

					}
					catch (Exception e) 
					{
						e.printStackTrace();
						errorCounter++;
						errorDetails= e.getMessage();//"Please check input file,should be in correct format.."+e.getMessage();
						LOG.error(errorDetails);
						DownloadFDMSOmnipayReportsAutomationUtils.writeErrorLogs(beanReader, beanWriter, beanErrorWriter, errorDetails, automationBeanWriter, automationBeanReader, errorCounter,
								dataFailed, headerWriter);
						File scrShotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
						String fileName = "Screenshot_FailedtoEnterMID_"+scrrenshotCounter + timeStamp + ".png";
						FileUtils.copyFile(scrShotFile, new File(ScreenShotFolder + "//" + currentdate + "//" + fileName));
						scrrenshotCounter++;

					}
					errorCounter = 0;
					long TotalTime = System.currentTimeMillis()-startTime;
					long inMin= TimeUnit.MILLISECONDS.toMinutes(System.currentTimeMillis()-startTime);
					LOG.info("Total time taken in miliseconds for row = "+beanReader.getRowNumber()+" ,time= "+  TimeUnit.MILLISECONDS.toSeconds(TotalTime)+"sec");
					LOG.info("Total time taken in minutes for row  = "+beanReader.getRowNumber()+" ,time= "+ inMin+"min");
					driver.navigate().refresh();
					Thread.sleep(4000);
					LOG.info("***************************************************************************************************************************");
				}//While LOOP
				}catch (Exception e) 
				{
					e.printStackTrace();
					errorDetails="Please check input file,should be in correct format.."+e.getMessage();
					LOG.error(errorDetails+" "+e.getMessage());
					DownloadFDMSOmnipayReportsAutomationUtils.writeErrorLogs(beanReader,beanWriter, beanErrorWriter, errorDetails,automationBeanWriter, automationBeanReader,
							errorCounter, dataFailed, headerWriter);
				}
				
			}//If loop
			else
			{
				errorDetails = "Please check username and password is correct or not";
				LOG.error(errorDetails);
				errorCounter++;
				DownloadFDMSOmnipayReportsAutomationUtils.writeErrorLogs(beanReader, beanWriter, beanErrorWriter, errorDetails, automationBeanWriter, automationBeanReader, 
						errorCounter, dataFailed, headerWriter);
			}
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			errorDetails="Please check input file,should be in correct format.."+e.getMessage();
			LOG.error(errorDetails+" "+e.getMessage());
			DownloadFDMSOmnipayReportsAutomationUtils.writeErrorLogs(beanReader,beanWriter, beanErrorWriter, errorDetails,automationBeanWriter, automationBeanReader,
					errorCounter, dataFailed, headerWriter);
		}
	}


	// close driver
	public void tearDown() throws Exception
	{
		try
		{
			driver.quit();

			LOG.info("driver " + DownloadFDMSOmnipayReportsAutomationMessages.CLOSED + "");
		} catch (Exception e)
		{
			e.printStackTrace();
			LOG.error("Error while quiting the driver " + e.getMessage());
		}
	}

	//Main function
	public static void main(String[] args) throws Exception
	{
		DownloadSubmissionsReportsMain automation=new DownloadSubmissionsReportsMain();
		automation.setUp();
		automation.TIDDeactivation_Process();
		automation.tearDown();
	}

}

package com.firstdata.fdms.omnipayreports.model;

import java.util.Date;

import org.supercsv.cellprocessor.ParseDate;
import org.supercsv.cellprocessor.ift.CellProcessor;

public class OutgoingInterchangeSummaryReportsReader
{

	private Date FROM_DATE;
	private String CARD_SCHEME;
	private String CURRENCY;

 

 
	public Date getFROM_DATE() {
		return FROM_DATE;
	}


	public void setFROM_DATE(Date fROM_DATE) {
		FROM_DATE = fROM_DATE;
	}


	public String getCARD_SCHEME() {
		return CARD_SCHEME;
	}


	public void setCARD_SCHEME(String cARD_SCHEME) {
		CARD_SCHEME = cARD_SCHEME;
	}


	public String getCURRENCY() {
		return CURRENCY;
	}


	public void setCURRENCY(String cURRENCY) {
		CURRENCY = cURRENCY;
	}


	public static CellProcessor[] getProcessors()
	{
		CellProcessor[] cellProcessorsReader = new CellProcessor[]
				{ 
				new ParseDate("dd/MM/yyyy"),
				null,
				null

				};
		return cellProcessorsReader;
	}


}

package com.firstdata.fdms.omnipayreports.model;

import org.supercsv.cellprocessor.ift.CellProcessor;

public class OutgoingInterchangeSummaryReportsWriter
{
	private String START_TIME;
	private String END_TIME;
	private String ROWNUM;
	private String FROM_DATE;
	private String CARD_SCHEME;
	private String CURRENCY;
	private String COMMENTS;



	public String getSTART_TIME() {
		return START_TIME;
	}





	public String getEND_TIME() {
		return END_TIME;
	}





	public String getROWNUM() {
		return ROWNUM;
	}



	public void setSTART_TIME(String sTARTTIME) {
		START_TIME = sTARTTIME;
	}





	public void setEND_TIME(String eNDTIME) {
		END_TIME = eNDTIME;
	}





	public void setROWNUM(String rOWNUM) {
		ROWNUM = rOWNUM;
	}




 





	 




	public String getFROM_DATE() {
		return FROM_DATE;
	}





	public void setFROM_DATE(String fROM_DATE) {
		FROM_DATE = fROM_DATE;
	}





	public String getCURRENCY() {
		return CURRENCY;
	}





	public void setCURRENCY(String cURRENCY) {
		CURRENCY = cURRENCY;
	}





	public String getCARD_SCHEME() {
		return CARD_SCHEME;
	}





	public void setCARD_SCHEME(String cARD_SCHEME) {
		CARD_SCHEME = cARD_SCHEME;
	}




 

	public String getCOMMENTS() {
		return COMMENTS;
	}





	public void setCOMMENTS(String cOMMENTS) {
		COMMENTS = cOMMENTS;
	}





	public static CellProcessor[] getProcessors()
	{

		CellProcessor[] cellProcessorsReader = new CellProcessor[]
	    { 
				null,
				null,
				null,
				null,
				null,
				null,
				null
	    };
		return cellProcessorsReader;
	}

}

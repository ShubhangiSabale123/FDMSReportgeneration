package com.firstdata.fdms.omnipayreports.model;

import java.util.Date;

import org.supercsv.cellprocessor.ParseDate;
import org.supercsv.cellprocessor.ift.CellProcessor;

public class SubmissionsReportsAutomationReader
{

	private Date  FROM_DATE;
	private Date TO_DATE;
	private String CURRENCY;

	 


	 


	public Date getFROM_DATE() {
		return FROM_DATE;
	}


	public void setFROM_DATE(Date fROM_DATE) {
		FROM_DATE = fROM_DATE;
	}


	public Date getTO_DATE() {
		return TO_DATE;
	}


	public void setTO_DATE(Date tO_DATE) {
		TO_DATE = tO_DATE;
	}


 
 


	public String getCURRENCY() {
		return CURRENCY;
	}


	public void setCURRENCY(String cURRENCY) {
		CURRENCY = cURRENCY;
	}


	public static CellProcessor[] getProcessors()
	{
		CellProcessor[] cellProcessorsReader = new CellProcessor[]
				{ 
				new ParseDate("dd/MM/yyyy"),
				new ParseDate("dd/MM/yyyy"),
				null

				};
		return cellProcessorsReader;
	}


}

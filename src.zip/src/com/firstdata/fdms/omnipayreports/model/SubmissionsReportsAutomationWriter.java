package com.firstdata.fdms.omnipayreports.model;

import org.supercsv.cellprocessor.ift.CellProcessor;

public class SubmissionsReportsAutomationWriter
{
	private String START_TIME;
	private String END_TIME;
	private String ROWNUM;
	private String FROM_DATE;
	private String TO_DATE;
	private String CURRENCY;
	private String COMMENTS;



	public String getSTART_TIME() {
		return START_TIME;
	}


	public String getEND_TIME() {
		return END_TIME;
	}


	public String getROWNUM() {
		return ROWNUM;
	}



	public void setSTART_TIME(String sTARTTIME) {
		START_TIME = sTARTTIME;
	}



	public void setEND_TIME(String eNDTIME) {
		END_TIME = eNDTIME;
	}





	public void setROWNUM(String rOWNUM) {
		ROWNUM = rOWNUM;
	}


 


	public String getFROM_DATE() {
		return FROM_DATE;
	}





	public void setFROM_DATE(String fROM_DATE) {
		FROM_DATE = fROM_DATE;
	}





	public String getTO_DATE() {
		return TO_DATE;
	}





	public void setTO_DATE(String tO_DATE) {
		TO_DATE = tO_DATE;
	}





	public String getCURRENCY() {
		return CURRENCY;
	}





	public void setCURRENCY(String cURRENCY) {
		CURRENCY = cURRENCY;
	}





	public String getCOMMENTS() {
		return COMMENTS;
	}





	public void setCOMMENTS(String cOMMENTS) {
		COMMENTS = cOMMENTS;
	}





	public static CellProcessor[] getProcessors()
	{

		CellProcessor[] cellProcessorsReader = new CellProcessor[]
	    { 
				null,
				null,
				null,
				null,
				null,
				null,
				null
	    };
		return cellProcessorsReader;
	}

}

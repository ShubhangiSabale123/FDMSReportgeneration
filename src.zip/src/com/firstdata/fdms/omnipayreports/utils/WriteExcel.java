package com.firstdata.fdms.omnipayreports.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class WriteExcel 
{
 static File src=null;
 static FileInputStream fis=null;
 static FileOutputStream fos= null;
 static XSSFWorkbook wb=null;
 static XSSFSheet sh=null;
 XSSFCell cell;
 XSSFRow row;
 
 	public  static void writeIntoExcel(String FilePath,int sheetNo,String Value,int row,int col) throws IOException
 	{
 		try
 		{
 		src= new File(FilePath);
 		fis= new FileInputStream(src);
 		wb= new XSSFWorkbook(fis);
 		sh=wb.getSheetAt(sheetNo);
 		sh.getRow(row).createCell(col).setCellValue(Value);
 		fis.close();
 		fos=new FileOutputStream(src);
 		wb.write(fos);
 		}
 		catch(Exception e)
 		{
 			System.out.println(e.getMessage());
 		}
 	}
 	
 	
}

package com.firstdata.fdms.omnipayreports.utils;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.supercsv.io.ICsvBeanReader;
import org.supercsv.io.ICsvBeanWriter;

import com.firstdata.fdms.omnipayreports.model.OutgoingInterchangeSummaryReportsReader;
import com.firstdata.fdms.omnipayreports.model.OutgoingInterchangeSummaryReportsWriter;





public class RenameCSVFileName 
{

	private static Logger LOG = LoggerFactory.getLogger(RenameCSVFileName.class);


	


	public static boolean renameAndMoveFile(WebDriver driver,String source, String destination, Properties properties,ICsvBeanReader beanReader, ICsvBeanWriter beanWriter,ICsvBeanWriter beanErrorWriter,String errorDetails,
			OutgoingInterchangeSummaryReportsWriter automationBeanWriter,OutgoingInterchangeSummaryReportsReader automationBeanReader, int errorCounter, String dataFailed, String[] headerWriter) throws  IOException

	{
		LOG.info("============Rename the file===============");
		boolean isFileRenamed = false;

		 

		try
		{
			Calendar cal = Calendar.getInstance();

			SimpleDateFormat formatStatus = new SimpleDateFormat("dd-MM-yyyy");// date format

			String currentdateStatus = formatStatus.format(cal.getTime());// current date (system date) as a string

			SimpleDateFormat formatStatus1 = new SimpleDateFormat("yyyyMMdd");// date format

			final String currentdateStatus1 = formatStatus1.format(cal.getTime());// current date (system date) as a
			// string

			File dir = new File(destination + "\\" + currentdateStatus);
			//new File("" + source + "\\" + currentdateStatus + "");
			dir.mkdir();
			Thread.sleep(1000);
			LOG.info("Dir= "+dir);
			//source=source+"\\" +currentdateStatus;
			Date getfromDate=automationBeanReader.getFROM_DATE();
			System.out.println("getfromDate= "+getfromDate);
			DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
			String strDate = dateFormat.format(getfromDate);
			System.out.println("strDate= "+strDate);
			File[] Fetchfile = new File(source).listFiles();
			List searchResults = null;
			
			for (File file : Fetchfile)
			{
				 
				if(file.isFile()&& (file.getName().toUpperCase().contains(properties.getProperty("username"))&& file.getName().endsWith(".csv")) )
				{	
					DownloadFDMSOmnipayReportsAutomationWaitTool.waitForFile(driver, file,properties.getProperty("maxtimeout"), properties.getProperty("pollingtimeout"));
				}
			}
			
			try
			{
				for (File file : Fetchfile)
				{
				 	 
					if(file.isFile()&& (file.getName().toUpperCase().contains(properties.getProperty("username"))&& file.getName().endsWith(".csv")) )
					{	
						DownloadFDMSOmnipayReportsAutomationWaitTool.waitForFile(driver, file,properties.getProperty("maxtimeout"), properties.getProperty("pollingtimeout"));
						//LOG.info("in if");
						try
						{
							LOG.info("filename= "+file.getName());
							//	File sourceFile = new File(source +"\\"+currentdateStatus1);
							LOG.info("sourceFile= "+file.getName());
							 
							String[] srcFile=file.getName().split(".csv");
							Thread.sleep(1000);
							boolean isFound=false;

							//PdfDocument doc = new PdfDocument();
							File oldName = new File(source+"\\"+file.getName());
							File newName = new File(dir+"\\"+automationBeanReader.getCURRENCY().trim()+"_"+automationBeanReader.getCARD_SCHEME()+"_"+strDate+".csv");
							LOG.info("File= "+source+"\\"+file.getName());//C:\Users\F4MG9WH\Downloads\download.pdf
							LOG.info("destination loc= "+ dir+"\\"+automationBeanReader.getCURRENCY().trim()+"_"+automationBeanReader.getCARD_SCHEME()+"_"+strDate+".csv");

							if(oldName.renameTo(newName))
							{
								LOG.info("File is renamed");
								isFileRenamed=true;
								break;
							} 


						}
						catch (Exception e)
						{
							errorCounter++;
							errorDetails = "..Failed to Rename file for  rowNumber="
									+ beanReader.getRowNumber() + "";
							LOG.error(errorDetails);
							DownloadOutgoingInterchangeAutomationUtils.writeErrorLogs(beanReader, beanWriter, beanErrorWriter, errorDetails, automationBeanWriter, automationBeanReader,
							 errorCounter, dataFailed, headerWriter);
						}
					}
				}
			}
			catch (Exception e) 
			{
				e.printStackTrace();
				errorCounter++;
				errorDetails = "failed to Rename file  on rowNumber="
						+ beanReader.getRowNumber() + "";
				LOG.error(errorDetails);
				 DownloadOutgoingInterchangeAutomationUtils.writeErrorLogs(beanReader, beanWriter, beanErrorWriter, errorDetails, automationBeanWriter, automationBeanReader,
				 	errorCounter, dataFailed, headerWriter);

			}


		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return isFileRenamed;
	}

}


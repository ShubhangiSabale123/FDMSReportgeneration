package com.firstdata.fdms.omnipayreports.utils;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanReader;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import com.firstdata.fdms.omnipayreports.model.SubmissionsReportsAutomationReader;
import com.firstdata.fdms.omnipayreports.model.SubmissionsReportsAutomationWriter;


public class DownloadFDMSOmnipayReportsAutomationUtils
{

	private static Logger LOG = LoggerFactory.getLogger(DownloadFDMSOmnipayReportsAutomationUtils.class);

	private static BufferedReader bufferedReader;
	public static Properties loadProperties(Properties properties, String fileName) throws Exception
	{
		properties = new Properties();
		bufferedReader = new BufferedReader(new FileReader(fileName));

		properties.load(bufferedReader);
		bufferedReader.close();

		return properties;
	}


	// Return a instance of By class based on type of locator
	public static WebElement getLocator(Properties objProperties, WebDriver driver, String ElementName) throws Exception
	{
		if (objProperties.getProperty(ElementName) != null)
		{
			// Read value using the logical name as Key
			String locator = objProperties.getProperty(ElementName);
			// Split the value which contains locator type and locator value
			String locatorType = locator.split(DownloadFDMSOmnipayReportsAutomationConstants.SEPARATOR)[0];
			String locatorValue = locator.split(DownloadFDMSOmnipayReportsAutomationConstants.SEPARATOR)[1];

			if (locatorType.toLowerCase().equals(DownloadFDMSOmnipayReportsAutomationConstants.LOCATORTYPE_ID))
			{
				return driver.findElement(By.id(locatorValue));
			} else if (locatorType.toLowerCase().equals(DownloadFDMSOmnipayReportsAutomationConstants.LOCATORTYPE_NAME))
			{
				return driver.findElement(By.name(locatorValue));
			} else if ((locatorType.toLowerCase().equals(DownloadFDMSOmnipayReportsAutomationConstants.LOCATORTYPE_CLASSNAME)) || (locatorType.toLowerCase().equals(DownloadFDMSOmnipayReportsAutomationConstants.LOCATORTYPE_CLASS)))
			{
				return driver.findElement(By.className(locatorValue));
			} else if ((locatorType.toLowerCase().equals(DownloadFDMSOmnipayReportsAutomationConstants.LOCATORTYPE_TAGNAME)) || (locatorType.toLowerCase().equals(DownloadFDMSOmnipayReportsAutomationConstants.LOCATORTYPE_TAG)))
			{
				return driver.findElement(By.tagName(locatorValue));
			} else if ((locatorType.toLowerCase().equals(DownloadFDMSOmnipayReportsAutomationConstants.LOCATORTYPE_LINKTEXT)) || (locatorType.toLowerCase().equals(DownloadFDMSOmnipayReportsAutomationConstants.LOCATORTYPE_LINK)))
			{
				return driver.findElement(By.linkText(locatorValue));
			} else if (locatorType.toLowerCase().equals(DownloadFDMSOmnipayReportsAutomationConstants.LOCATORTYPE_PARTIALLINKTEXT))
			{
				return driver.findElement(By.partialLinkText(locatorValue));
			} else if ((locatorType.toLowerCase().equals(DownloadFDMSOmnipayReportsAutomationConstants.LOCATORTYPE_CSSSELECTOR)) || (locatorType.toLowerCase().equals(DownloadFDMSOmnipayReportsAutomationConstants.LOCATORTYPE_CSS)))
			{
				return driver.findElement(By.cssSelector(locatorValue));
			} else if (locatorType.toLowerCase().equals(DownloadFDMSOmnipayReportsAutomationConstants.LOCATORTYPE_XPATH))
			{
				return driver.findElement(By.xpath(locatorValue));
			} else
			{
				LOG.error("Locator type '" + locatorType + "' not defined!!");
				throw new Exception("Locator type '" + locatorType + "' not defined!!");
			}
		} else
		{
			LOG.error("Locator " + ElementName + " is null");
			throw new Exception("Locator " + ElementName + " is null");
		}
	}

	//for list of elements	  
	public static List<WebElement> getLocators(Properties objProperties, WebDriver driver, String ElementName) throws Exception
	{
		if (objProperties.getProperty(ElementName) != null)
		{
			// Read value using the logical name as Key
			String locator = objProperties.getProperty(ElementName);
			// Split the value which contains locator type and locator value
			String locatorType = locator.split(DownloadFDMSOmnipayReportsAutomationConstants.SEPARATOR)[0];
			String locatorValue = locator.split(DownloadFDMSOmnipayReportsAutomationConstants.SEPARATOR)[1];

			if (locatorType.toLowerCase().equals(DownloadFDMSOmnipayReportsAutomationConstants.LOCATORTYPE_ID))
			{
				return driver.findElements(By.id(locatorValue));
			} else if (locatorType.toLowerCase().equals(DownloadFDMSOmnipayReportsAutomationConstants.LOCATORTYPE_NAME))
			{
				return driver.findElements(By.name(locatorValue));
			} else if ((locatorType.toLowerCase().equals(DownloadFDMSOmnipayReportsAutomationConstants.LOCATORTYPE_CLASSNAME)) || (locatorType.toLowerCase().equals(DownloadFDMSOmnipayReportsAutomationConstants.LOCATORTYPE_CLASS)))
			{
				return driver.findElements(By.className(locatorValue));
			} else if ((locatorType.toLowerCase().equals(DownloadFDMSOmnipayReportsAutomationConstants.LOCATORTYPE_TAGNAME)) || (locatorType.toLowerCase().equals(DownloadFDMSOmnipayReportsAutomationConstants.LOCATORTYPE_TAG)))
			{
				return driver.findElements(By.tagName(locatorValue));
			} else if ((locatorType.toLowerCase().equals(DownloadFDMSOmnipayReportsAutomationConstants.LOCATORTYPE_LINKTEXT)) || (locatorType.toLowerCase().equals(DownloadFDMSOmnipayReportsAutomationConstants.LOCATORTYPE_LINK)))
			{
				return driver.findElements(By.linkText(locatorValue));
			} else if (locatorType.toLowerCase().equals(DownloadFDMSOmnipayReportsAutomationConstants.LOCATORTYPE_PARTIALLINKTEXT))
			{
				return driver.findElements(By.partialLinkText(locatorValue));
			} else if ((locatorType.toLowerCase().equals(DownloadFDMSOmnipayReportsAutomationConstants.LOCATORTYPE_CSSSELECTOR)) || (locatorType.toLowerCase().equals(DownloadFDMSOmnipayReportsAutomationConstants.LOCATORTYPE_CSS)))
			{
				return driver.findElements(By.cssSelector(locatorValue));
			} else if (locatorType.toLowerCase().equals(DownloadFDMSOmnipayReportsAutomationConstants.LOCATORTYPE_XPATH))
			{
				return driver.findElements(By.xpath(locatorValue));
			} else
			{
				LOG.error("Locator type '" + locatorType + "' not defined!!");
				throw new Exception("Locator type '" + locatorType + "' not defined!!");
			}
		} else
		{
			LOG.error("Locator " + ElementName + " is null");
			throw new Exception("Locator " + ElementName + " is null");
		}
	}

	//
	public static  WebDriver getBrowser(String  browser,WebDriver driver,Properties properties)
	{
		try
		{
			if(browser.equalsIgnoreCase("firefox"))
			{
				String firefoxExe = properties.getProperty("firefoxExe").trim();
				//create firefox instance
				FirefoxBinary binary = new FirefoxBinary(new File(firefoxExe));
				FirefoxProfile profile = new FirefoxProfile();

				driver = new FirefoxDriver();
			}
			//Check if parameter passed as 'chrome'
			else if(browser.equalsIgnoreCase("chrome"))
			{
				 String chromeServerPath = properties.getProperty("chromedriverPath");
	                System.setProperty("webdriver.chrome.driver",chromeServerPath);
	                //driver = new ChromeDriver();
	                ChromeOptions options = new ChromeOptions();
	                options.addArguments("disable-infobars");
	                options.addArguments("--start-maximized");
	                options.addArguments("no-sandbox");
	             
	                DesiredCapabilities disredcap=DesiredCapabilities.chrome();
	                disredcap.setCapability(ChromeOptions.CAPABILITY, options);
	                disredcap.setVersion(properties.getProperty("chromeBrowserVersion"));
	                disredcap.setPlatform(Platform.WINDOWS);
	                driver = new ChromeDriver(options);
			}
			else if(browser.equalsIgnoreCase("ie"))
			{
				String IEServerPath = properties.getProperty("IEServerPath");

				//Set Property for IE Browser
				System.setProperty("webdriver.ie.driver",IEServerPath);

				DesiredCapabilities caps = DesiredCapabilities.internetExplorer();

				caps.setCapability("EnableNativeEvents", false);
				caps.setCapability("ignoreZoomSetting", true);

				//Set capability of IE driver to Ignore all zones browser protected mode settings.
				caps.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,true);

				driver = new InternetExplorerDriver(caps);

			}
			else
			{
				//If no browser passed  
				throw new Exception("Browser is not correct");
			}
		}
		catch (Exception e)
		{  

		}
		return driver;


	}

	public static void writeRecordStatus(WebDriver driver,SubmissionsReportsAutomationWriter automationBeanWriter, ICsvBeanWriter beanWriter, ICsvBeanReader beanReader, String[] headerWriter) throws Exception
	{
		try
		{

			automationBeanWriter.setEND_TIME(String.valueOf(new SimpleDateFormat(DownloadFDMSOmnipayReportsAutomationConstants.TIMESTAMP).format(new Date())));


			automationBeanWriter.setCOMMENTS(DownloadFDMSOmnipayReportsAutomationMessages.PROCESSED);


			//LOG.info("   Automation Ended For Row (" + beanReader.getRowNumber() + ") on : " + new SimpleDateFormat(TIDDeactivationAutomationConstants.TIMESTAMP).format(new Date()));

			beanWriter.write(automationBeanWriter, headerWriter, SubmissionsReportsAutomationWriter.getProcessors());

			beanWriter.flush();

			Thread.sleep(50);

		} catch (Exception e)
		{
			e.printStackTrace();
			LOG.error(e.getMessage());
		}
	}
	public static void writeErrorLogs(ICsvBeanReader beanReader, ICsvBeanWriter beanWriter,ICsvBeanWriter beanErrorWriter,String errorDetails,
			SubmissionsReportsAutomationWriter automationBeanWriter,SubmissionsReportsAutomationReader automationBeanReader, int errorCounter, String dataFailed, String[] headerWriter)
	{
		LOG.info("---------------------------In  writeErrorLog------------------------------");
		try
		{
			beanErrorWriter = new CsvBeanWriter(new FileWriter(dataFailed, true), CsvPreference.STANDARD_PREFERENCE);
			automationBeanWriter.setEND_TIME((String.valueOf(new SimpleDateFormat( DownloadFDMSOmnipayReportsAutomationConstants.TIMESTAMP).format(new Date()))));



			if(automationBeanReader.getFROM_DATE()==null)
			{
				automationBeanWriter.setFROM_DATE(DownloadFDMSOmnipayReportsAutomationConstants.NULL);
			}
			else
			{
				automationBeanWriter.setFROM_DATE("'"+automationBeanReader.getFROM_DATE());
			}
			
			if(automationBeanReader.getTO_DATE()==null)
			{
				automationBeanWriter.setTO_DATE(DownloadFDMSOmnipayReportsAutomationConstants.NULL);
			}
			else
			{
				automationBeanWriter.setTO_DATE("'"+automationBeanReader.getTO_DATE());
			}
			
			if(automationBeanReader.getCURRENCY()==null)
			{
				automationBeanWriter.setCURRENCY(DownloadFDMSOmnipayReportsAutomationConstants.NULL);
			}
			else
			{
				automationBeanWriter.setCURRENCY("'"+automationBeanReader.getCURRENCY());
			}

			automationBeanWriter.setCOMMENTS(errorDetails);

			//beanErrorWriter = new CsvBeanWriter(new FileWriter(dataFailed,true), CsvPreference.STANDARD_PREFERENCE); 
			beanErrorWriter.write(automationBeanWriter, headerWriter, SubmissionsReportsAutomationWriter.getProcessors());
			try
			{
				LOG.info("write in status file for error");
				if (errorCounter==1)
				{
					LOG.info("error");
					automationBeanWriter.setCOMMENTS(DownloadFDMSOmnipayReportsAutomationConstants.ERROR);           
					beanWriter.write(automationBeanWriter, headerWriter, SubmissionsReportsAutomationWriter.getProcessors());                 
					beanWriter.flush();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
				LOG.info("in catch");
			}

			beanErrorWriter.flush();
			beanErrorWriter.close();

		} catch (Exception e)
		{
			e.printStackTrace();
			LOG.error(e.getMessage());
		}
	}


	public static WebDriver login(Properties objProperties, WebDriver driver, String username, String password,Properties properties)
	{
		try
		{
			LOG.info("Login " + DownloadFDMSOmnipayReportsAutomationMessages.STARTED + "");

			WebElement userNameWebElement = DownloadFDMSOmnipayReportsAutomationUtils.getLocator(objProperties, driver, "username_TextBox");
			DownloadFDMSOmnipayReportsAutomationWaitTool.waitForVisibilityOfElement(driver, userNameWebElement, properties.getProperty("timeoutfor_element_tobevisible"));
			userNameWebElement.clear(); // clears the textbox of username
			// input value to username
			userNameWebElement.sendKeys(username);

			WebElement passwordWebElement = DownloadFDMSOmnipayReportsAutomationUtils.getLocator(objProperties, driver, "password_TextBox");
			DownloadFDMSOmnipayReportsAutomationWaitTool.waitForVisibilityOfElement(driver, passwordWebElement, properties.getProperty("timeoutfor_element_tobevisible"));
			passwordWebElement.clear();    // clears the textbox of password
			passwordWebElement.sendKeys(password); // input value to password

			WebElement login = DownloadFDMSOmnipayReportsAutomationUtils.getLocator(objProperties, driver, "loginButton");
			DownloadFDMSOmnipayReportsAutomationWaitTool.waitForElementToBeClickable(driver, login,properties.getProperty("timeoutfor_element_tobeclickable"));
			login.click();   // click on login button

			LOG.info("Login " + DownloadFDMSOmnipayReportsAutomationMessages.FINISHED + "");

		} catch (Exception e)
		{
			e.printStackTrace();
			LOG.error("Error while login to Rupay web portal" + e.getMessage());
		}
		return driver;
	}

	public static boolean isMandatory(ICsvBeanReader beanReader, ICsvBeanWriter beanWriter, ICsvBeanWriter beanErrorWriter, String errorDetails,
			SubmissionsReportsAutomationWriter automationBeanWriter,SubmissionsReportsAutomationReader automationBeanReader, int errorCounter, String dataFailed, String[] headerWriter)
	{
		LOG.info("Mandatory fields Validation " + DownloadFDMSOmnipayReportsAutomationMessages.STARTED + "");
		boolean isMandatoryPresent = true;

		if (automationBeanReader.getCURRENCY() == null)
		{
			errorDetails = "CURRENCY is null in csv on row " + beanReader.getRowNumber() + "";
			LOG.error(errorDetails);
			isMandatoryPresent = false;
			errorCounter++;
			DownloadFDMSOmnipayReportsAutomationUtils.writeErrorLogs(beanReader, beanWriter, beanErrorWriter, errorDetails,
					automationBeanWriter, automationBeanReader, errorCounter, dataFailed, headerWriter);
		}
		else
		{
			if(automationBeanReader.getCURRENCY().trim().isEmpty())
			{
				errorDetails = "CURRENCY is null in csv on row " + beanReader.getRowNumber() + "";
				LOG.error(errorDetails);
				isMandatoryPresent = false;
				errorCounter++;
				DownloadFDMSOmnipayReportsAutomationUtils.writeErrorLogs(beanReader, beanWriter, beanErrorWriter, errorDetails,
						automationBeanWriter, automationBeanReader, errorCounter, dataFailed, headerWriter);
			}
		}
		
		if (automationBeanReader.getFROM_DATE() == null)
		{
			errorDetails = "FROM_DATE is null in csv on row " + beanReader.getRowNumber() + "";
			LOG.error(errorDetails);
			isMandatoryPresent = false;
			errorCounter++;
			DownloadFDMSOmnipayReportsAutomationUtils.writeErrorLogs(beanReader, beanWriter, beanErrorWriter, errorDetails,
					automationBeanWriter, automationBeanReader, errorCounter, dataFailed, headerWriter);
		}
		 
		if (automationBeanReader.getTO_DATE()== null)
		{
			errorDetails = "TO_DATE is null in csv on row " + beanReader.getRowNumber() + "";
			LOG.error(errorDetails);
			isMandatoryPresent = false;
			errorCounter++;
			DownloadFDMSOmnipayReportsAutomationUtils.writeErrorLogs(beanReader, beanWriter, beanErrorWriter, errorDetails,
					automationBeanWriter, automationBeanReader, errorCounter, dataFailed, headerWriter);
		}
		 
		return isMandatoryPresent;

	}
}

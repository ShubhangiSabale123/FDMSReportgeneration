package com.firstdata.fdms.omnipayreports.utils;

public class DownloadFDMSOmnipayReportsAutomationMessages
{

	public static String STARTED = "Started : ";
	public static String FINISHED = "Finished : ";
	public static String CLOSED = "Closed : ";
	public static String PROCESSED = "Processed";
}

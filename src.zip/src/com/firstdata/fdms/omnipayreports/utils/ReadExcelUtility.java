package com.firstdata.fdms.omnipayreports.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.util.Date;

import org.apache.commons.lang3.time.DateUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcelUtility {
	File src=null;
	FileInputStream fis=null;
	XSSFWorkbook wb= null;
	XSSFSheet sh;
	XSSFRow  row=null;
	Cell cell=null;

	public ReadExcelUtility(String ExcelPath) throws IOException
	{
		try
		{
			System.out.println("ExcelPath= "+ExcelPath);
			File src= new File(ExcelPath);
			fis=new FileInputStream(src);
			wb= new XSSFWorkbook(fis);
			System.out.println(wb);

		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	public int sheetCount() 
	{

		int sheetCount =wb.getNumberOfSheets();	
		return sheetCount;		
	}

	public int getRowCount(int sheetIndex)
	{
		sh=wb.getSheetAt(sheetIndex);
		int rowCount=sh.getLastRowNum();
		return rowCount;

	}
	public int getColCount(int sheetIndex)
	{
		sh=wb.getSheetAt(sheetIndex);
		row=sh.getRow(0);
		int colCount=row.getLastCellNum();
		return colCount;
	}		
	public String getData(int sheetNo, int row, int col) throws ParseException
	{
		sh=wb.getSheetAt(sheetNo);
		cell=sh.getRow(row).getCell(col);//.getStringCellValue();
		System.out.println(cell);
		 
		if(cell.getCellTypeEnum()==CellType.STRING)
		{
			return cell.getStringCellValue();
		}
		else if(DateUtil.isCellDateFormatted(cell))
				//getCellTypeEnum()==CellType.NUMERIC)
		{
			 //System.out.println(cell);
			 Cell cell= sh.getRow(row).getCell(col);
			 String orderID1=cell.toString();
			 
			// System.out.println("orderID1="+orderID1);
			 Date date1=new SimpleDateFormat("dd-MMM-yyyy").parse(orderID1);  
			 System.out.println(date1);
			 SimpleDateFormat  dateFormat=new SimpleDateFormat("dd/MM/yyyy");
			//   System.out.println("Date :"+dateFormat.format(date1));
			/*DateFormat dateForma1t = new SimpleDateFormat("dd/mm/yyyy");  
            String strDate = dateFormat1.format(date1);  */
          //  System.out.println("strDate"+strDate);
			return dateFormat.format(date1);//.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

		} 
		else
			return cell.getStringCellValue();
	}

	 



}



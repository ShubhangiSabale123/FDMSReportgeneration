package com.firstdata.fdms.omnipayreports.utils;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.supercsv.io.ICsvBeanReader;
import org.supercsv.io.ICsvBeanWriter;

import com.firstdata.fdms.omnipayreports.model.SubmissionsReportsAutomationReader;
import com.firstdata.fdms.omnipayreports.model.SubmissionsReportsAutomationWriter;


public class RenameExcelFileName 
{

	private static Logger LOG = LoggerFactory.getLogger(RenameExcelFileName.class);

	public static boolean renameAndMoveFile(WebDriver driver,String source, String destination, Properties properties,ICsvBeanReader beanReader, ICsvBeanWriter beanWriter,ICsvBeanWriter beanErrorWriter,String errorDetails,
			SubmissionsReportsAutomationWriter automationBeanWriter,SubmissionsReportsAutomationReader automationBeanReader, int errorCounter, String dataFailed, String[] headerWriter) throws  IOException

	{
		LOG.info("============Rename the file===============");
		boolean isFileRenamed = false;
		boolean isFileFolderCreated=false;


		try
		{
			String fromdate = null;
			Calendar cal = Calendar.getInstance();

			SimpleDateFormat formatStatus = new SimpleDateFormat("dd-MM-yyyy");// date format

			String currentdateStatus = formatStatus.format(cal.getTime());// current date (system date) as a string

			SimpleDateFormat formatStatus1 = new SimpleDateFormat("yyyyMMdd");// date format

			final String currentdateStatus1 = formatStatus1.format(cal.getTime());// current date (system date) as a
			// string

			File  dir = new File(destination + "\\" + currentdateStatus);
			try
			{

				//new File("" + source + "\\" + currentdateStatus + "");

				dir.mkdir();
				Thread.sleep(500);
				LOG.info("Dir= "+dir);
				isFileFolderCreated=true;
			}
			catch(Exception e)
			{
				isFileFolderCreated=false;
				errorCounter++;
				errorDetails = "Please check output folder path"
						+ beanReader.getRowNumber() + "";
				LOG.error(errorDetails);
				DownloadFDMSOmnipayReportsAutomationUtils.writeErrorLogs(beanReader, beanWriter, beanErrorWriter, errorDetails, automationBeanWriter, automationBeanReader,
						errorCounter, dataFailed, headerWriter);
			}





			/*	Calendar calxls = Calendar.getInstance();
			SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy");
			fromdate = format.format();*/

			Date getfromDate=automationBeanReader.getFROM_DATE();
			System.out.println("getfromDate= "+getfromDate);
			//Date date1=new SimpleDateFormat("dd/MM/yyyy").parse(getfromDate);
			System.out.println(getfromDate+"\t"+getfromDate);

			Date date = Calendar.getInstance().getTime();
			DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
			String strDate = dateFormat.format(getfromDate);
			System.out.println("strDate= "+strDate);

			File[] Fetchfile =null;
			try
			{
				Fetchfile = new File(source).listFiles();
				List searchResults = null;

				for (File file : Fetchfile)
				{
					//System.out.println("filename= "+file.getName().endsWith(".pdf"));


					//if(file.isFile()&& (file.getName().toUpperCase().contains(properties.getProperty("username").toUpperCase())&& file.getName().endsWith(".xls")) )
					if(file.isFile()&& (file.getName().toUpperCase().contains("SUBMISSION_SEARCH")&& file.getName().endsWith(".xls")) )
					{	
						DownloadFDMSOmnipayReportsAutomationWaitTool.waitForFile(driver, file,properties.getProperty("maxtimeout"), properties.getProperty("pollingtimeout"));
						break;
					}

				}
			}
			catch(Exception e)
			{
				isFileRenamed=false;
				errorCounter++;
				errorDetails = "Please check DownlaodFilePath" ;

				LOG.error(errorDetails);
				DownloadFDMSOmnipayReportsAutomationUtils.writeErrorLogs(beanReader, beanWriter, beanErrorWriter, errorDetails, automationBeanWriter, automationBeanReader,
						errorCounter, dataFailed, headerWriter);
			}
			try
			{
				if(isFileFolderCreated)
				{
					for (File file : Fetchfile)
					{
						//System.out.println("filename= "+file.getName().endsWith(".pdf"));
						//if(file.isFile()&& (file.getName().toUpperCase().contains(properties.getProperty("username").toUpperCase())&& file.getName().endsWith(".xls")) )

						if(file.isFile()&& (file.getName().toUpperCase().contains("SUBMISSION_SEARCH")&& file.getName().endsWith(".xls")) )
						{
							//LOG.info("in if");
							try
							{
								//LOG.info("filename= "+file.getName());
								//	File sourceFile = new File(source +"\\"+currentdateStatus1);
								LOG.info("sourceFile= "+file.getName());
								//File newfile = new File( source+"\\"+ARN + "_1.doc");
								Thread.sleep(200);
								boolean isFound=false;
								String[] srcFile=file.getName().split(".xls");


								//PdfDocument doc = new PdfDocument();
								File oldName = new File(source+"\\"+file.getName());
								File newName = new File(dir+"\\"+srcFile[0]+"_"+automationBeanReader.getCURRENCY()+"_"+strDate+".xls");
								LOG.info("File= "+source+"\\"+file.getName());//C:\Users\F4MG9WH\Downloads\download.pdf
								//LOG.info("destination loc= "+ dir+"\\"+automationBeanReader.getMID()+".csv");

								if(oldName.renameTo(newName))
								{
									LOG.info("File is renamed");
									isFileRenamed=true;
									break;
								} 


							}
							catch (Exception e)
							{
								isFileRenamed=false;
								errorCounter++;
								errorDetails = "..Failed to Rename file "  + " on rowNumber="
										+ beanReader.getRowNumber() + "";
								LOG.error(errorDetails);
								DownloadFDMSOmnipayReportsAutomationUtils.writeErrorLogs(beanReader, beanWriter, beanErrorWriter, errorDetails, automationBeanWriter, automationBeanReader,
										errorCounter, dataFailed, headerWriter);
							}
						}
						/*else
						{
							errorCounter++;
							errorDetails = "failed to Rename file "  + " on rowNumber="
									+ beanReader.getRowNumber() + "";
							LOG.error(errorDetails);
							DownloadFDMSOmnipayReportsAutomationUtils.writeErrorLogs(beanReader, beanWriter, beanErrorWriter, errorDetails, automationBeanWriter, automationBeanReader,
									errorCounter, dataFailed, headerWriter);
						}*/
					}
				}
				else
				{
					errorCounter++;
					errorDetails = "unable to create folder in output folder "  + " on rowNumber="+ beanReader.getRowNumber() + "";
					LOG.error(errorDetails);
					DownloadFDMSOmnipayReportsAutomationUtils.writeErrorLogs(beanReader, beanWriter, beanErrorWriter, errorDetails, automationBeanWriter, automationBeanReader,
							errorCounter, dataFailed, headerWriter);
				}

			}
			catch (Exception e) 
			{
				e.printStackTrace();
				errorCounter++;
				errorDetails = "failed to Rename file "  + " on rowNumber="+ beanReader.getRowNumber() + "";
				LOG.error(errorDetails);
				DownloadFDMSOmnipayReportsAutomationUtils.writeErrorLogs(beanReader, beanWriter, beanErrorWriter, errorDetails, automationBeanWriter, automationBeanReader,
						errorCounter, dataFailed, headerWriter);

			}


		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return isFileRenamed;
	}

}


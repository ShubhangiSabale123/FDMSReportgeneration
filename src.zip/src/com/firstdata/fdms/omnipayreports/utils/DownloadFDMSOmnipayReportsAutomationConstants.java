package com.firstdata.fdms.omnipayreports.utils;

public class DownloadFDMSOmnipayReportsAutomationConstants {
	public static String PROCESSED = "Processed";
	  public static final String ERROR = "Error";
	  public static final String NULL = "null";
	  public static final String SEPARATOR = ":";
	  public static final String COMMA_SEPARATOR = ",";
	  public static final String LOCATORTYPE_ID = "id";
	  public static final String LOCATORTYPE_NAME = "name";
	  public static final String LOCATORTYPE_CLASSNAME = "classname";
	  public static final String LOCATORTYPE_CLASS = "class";
	  public static final String LOCATORTYPE_TAGNAME = "tagname";
	  public static final String LOCATORTYPE_TAG = "tag";
	  public static final String LOCATORTYPE_LINKTEXT = "linktext";
	  public static final String LOCATORTYPE_LINK = "link";
	  public static final String LOCATORTYPE_PARTIALLINKTEXT = "partiallinktext";
	  public static final String LOCATORTYPE_CSSSELECTOR = "cssselector";
	  public static final String LOCATORTYPE_CSS = "css";
	  public static final String LOCATORTYPE_XPATH = "xpath";
	  public static final String TIMESTAMP = "dd/MM/yyyy HH:mm:ss";
	  public static final String SCREENSHOT_TIMESTAMP = "dd-MM-yyyy-HH-mm-ss";
	  public static final String DATE_TRADING_FORMAT = "mm/yyyy";
	  public static final String PRINCIPAL_DATE_OF_BIRTH_FORMAT = "dd/mm/yyyy";
	  public static final String ACCOUNT_SIGNED_DATE_FORMAT = "dd/mm/yyyy";
	  public static final String MCC_SEPARATOR = "=";
	  public static final String DATE_TRADING_SEPARATOR = "/";
	  public static final String DROP_DOWN_SEPARATOR = "##";
	  public static final String PRINCIPAL_2_PIN_CODE = "PRINCIPAL_2_PIN_CODE";
	  public static final String PRINCIPAL_DATE_OF_BIRTH_PATTERN = "^(3[01]|[12][0-9]|0[1-9])/(1[0-2]|0[1-9])/[0-9]{4}$";
	  public static final String ALPHANUMERIC_PATTERN = "^[a-zA-Z0-9]*$";
	  public static final String SPECIAL_CHARACTER_PATTERN = "[" + "-/@#!*$%^&.'_+={}()" + "]+";
	  public static final String NUMBER_CHECK_PATTERN = "[0-9]+";
	  public static final String IFSC_CODE_PATTERN = "[A-Z|a-z]{4}[0][0-9|A-Z|a-z]{6}$";
	  public static final String IFSC_CODE_ALERT = "^This is an invalid IFSC Number\\.\nDo you want to continue[\\s\\S]$";
	  public static final String EMAIL_ID_PATTERN = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$";
	  public static final String BSB_NUMBER_PATTERN="[0-9]{3}-[0-9]{3}";
	}
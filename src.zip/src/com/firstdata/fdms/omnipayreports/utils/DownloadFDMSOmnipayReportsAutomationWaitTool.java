package com.firstdata.fdms.omnipayreports.utils;

import java.io.File;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Function;


public class DownloadFDMSOmnipayReportsAutomationWaitTool 
{
	private static Logger LOG = LoggerFactory.getLogger(DownloadFDMSOmnipayReportsAutomationWaitTool.class);
	public static WebElement waitForElementToBeClickable(WebDriver driver,WebElement locator,  String timeoutforelemttobeclickable)
	{
		WebElement element=null;
		try
		{
			WebDriverWait wait = new WebDriverWait(driver, Long.parseLong(timeoutforelemttobeclickable));
			element=wait.until(ExpectedConditions.elementToBeClickable(locator));
		}
		catch (Exception e)
		{
			e.printStackTrace();
			LOG.error("Error while  to waitForElementToBeClickable"+e.getMessage());
		}
		return element;

	}
	 
	public static WebElement  waitForVisibilityOfElement(WebDriver driver,WebElement locator,  String timeoutforelemttobevisible)
	{
		WebElement element=null;
		try
		{
			WebDriverWait wait = new WebDriverWait(driver,Long.parseLong(timeoutforelemttobevisible));
			element = wait.until(ExpectedConditions.visibilityOf(locator));
			return element;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			LOG.error("Error while  to waitForVisibilityOfElement"+e.getMessage());
		}
		return element;

	}
	
	//multiple elements
	
	public static List<WebElement>  waitForElementsToBeClickable(WebDriver driver,List<WebElement> locator,  String timeoutforelemttobevisible)
	{
		List<WebElement> elements=null;
		try
		{
			WebDriverWait wait = new WebDriverWait(driver,Long.parseLong(timeoutforelemttobevisible));
			elements = wait.until(ExpectedConditions.visibilityOfAllElements(locator));
			return elements;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			LOG.error("Error while  to waitForVisibilityOfElement"+e.getMessage());
		}
		return elements;

	}
	public static void waitForFile(WebDriver driver, File file, String maxtimeout,String pollingtimeout) 
	{
		Wait<WebDriver> wait = new FluentWait(driver)
		.withTimeout(Long.parseLong(maxtimeout), TimeUnit.SECONDS)
		.pollingEvery(Long.parseLong(pollingtimeout), TimeUnit.SECONDS);
		wait.until((webDriver) -> file.exists());
	}
	 
	
	//fluent wait
		public static WebElement   fluentWait(WebDriver driver, final WebElement element,  String maxtimeout,String pollingtimeout)
		{
			try
			{
				Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
				.withTimeout(Long.parseLong(maxtimeout), TimeUnit.SECONDS)
				.pollingEvery(Long.parseLong(pollingtimeout), TimeUnit.SECONDS)
				.ignoring(NoSuchElementException.class);

				WebElement foo = wait.until(new Function<WebDriver, WebElement>()
						{
					public WebElement apply(WebDriver driver) 
					{
						return element;
					}
						});
			}
			catch (Exception e) 
			{
				e.printStackTrace();
			}
			return null;

		}
	
	/*public static WebDriver waitForPageLoad(WebDriver wdriver)
	{
		
	    //WebDriverWait wait = new WebDriverWait(wdriver,Long.parseLong(timeoutforPageload));
	    WebDriverWait wait = new WebDriverWait(wdriver, 120);

	    Predicate<WebDriver> pageLoaded = new Predicate<WebDriver>() {

	        @Override
	        public boolean apply(WebDriver input) {
	            return ((JavascriptExecutor) input).executeScript("return document.readyState").equals("complete");
	        }

	    };
	    wait.until(pageLoaded);
	    System.out.println("Page Loaded Completely");
		return wdriver;
	}
	*/
	
	 
	public static void waitForLoad(WebDriver driver) {
        ExpectedCondition<Boolean> pageLoadCondition = new
                ExpectedCondition<Boolean>() {
                    public Boolean apply(WebDriver driver) {
                        return ((JavascriptExecutor)driver).executeScript("return document.readyState").equals("complete");
                    }

					@Override
					public <V> java.util.function.Function<WebDriver, V> andThen(
							java.util.function.Function<? super Boolean, ? extends V> arg0) {
						// TODO Auto-generated method stub
						return null;
					}

					@Override
					public <V> java.util.function.Function<V, Boolean> compose(
							java.util.function.Function<? super V, ? extends WebDriver> arg0) {
						// TODO Auto-generated method stub
						return null;
					}

					public <T> java.util.function.Function<T, T> identity() {
						// TODO Auto-generated method stub
						return null;
					}
                };
        WebDriverWait wait = new WebDriverWait(driver, 300000);
        wait.until(pageLoadCondition);
        System.out.println("Page Loaded Completely");
    }
	
	
}
